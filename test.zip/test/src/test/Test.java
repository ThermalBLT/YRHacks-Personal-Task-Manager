package test;

import java.util.Scanner;

public class Test {
    
    public static void main(String args[]){
        String toPrint = "";
        for (int x = 0; x < 100; x++) {
            int random = (int) (Math.random()*6) + 1;
            System.out.print(random + "\n");
            int highest = 0;
            for (int i = 0; i < random; i++) {
                int rand2 = (int) (Math.random()*52) + 1;
                int temp = 0;
                if (rand2 <= 12) {
                    temp = 1;
                } else if (rand2 > 12 && rand2 <=15) {
                    temp = 2;
                } else if (rand2 == 16) {
                    temp = 3;
                }
                if (temp > highest) {
                    highest = temp;
                }
            }
            toPrint = toPrint + (highest + "\n");
        }
        System.out.println("a\n\n" + toPrint);
    }
} 