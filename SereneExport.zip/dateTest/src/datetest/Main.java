package datetest;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

class Main implements Runnable{
    private int days;
    
public Main(int days){
    this.days = days;
}
    public void run(){
       //for (int i= seconds; i>=0; i--){
           //System.out.println(i);
           //try{
               //Thread.sleep(1000);
           //}
           //catch(Exception e){
               //System.out.println(e);
           //}
           for (int day= days; day>=0; day--){
           System.out.println("days remaining "+day);
           try{
               Thread.sleep(86400000);
           }
           catch(Exception e){
               System.out.println(e);
           }
       } 
       }
}


