/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package datetest;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author seren_3m8ao4l
 */
public class DateTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int dayAmt=0;
        Scanner user= new Scanner(System.in);
        System.out.print("date (dd/mm/yyyy)");
        String dateIn=user.next();
        int dayIn= Integer.parseInt(dateIn.substring(0,2));
        int monthIn= Integer.parseInt(dateIn.substring(3,5));
        int yearIn= Integer.parseInt(dateIn.substring(8));
        Date todayDate= new Date();
        SimpleDateFormat timeF= new SimpleDateFormat("dd,MM,yy");
        String dateT =timeF.format(todayDate);
        int dayT= Integer.parseInt(dateT.substring(0,2));
        int monthT= Integer.parseInt(dateT.substring(3,5));
        int yearT= Integer.parseInt(dateT.substring(6,8));
        int dayDiff= dayIn-dayT;
        int monthDiff= monthIn-monthT;
        int yearDiff= yearIn-yearT;
        int monthDay=30;
            if(monthT%2==1){
                if(monthT==7){
                        monthDay=30;
                    }
                    else{
                        monthDay++;
                    }
                }
                if(monthT==2){
                    monthDay=28;
                }
        if(yearDiff<0){
            System.out.println("invalid date");
        }
        else{
        if (dayDiff<0&&monthDiff<0){
            if(yearDiff>0){
                yearDiff--;
                monthDiff=11+monthDiff;
                dayDiff=monthDay+dayDiff;
            }
            else{
                System.out.println("invalid");
            }
        }
        else if (dayDiff<0){
            if(monthDiff>0){
                
                monthDiff--;
                dayDiff=monthDay+dayDiff;
                dayDiff+=1;
            }
            else if(yearDiff>0){
                yearDiff--;
                dayDiff=365+dayDiff;
            }
            else {
                System.out.println("invalid date");
            }
        }
        else if (monthDiff<0){
            if (yearDiff>0){
                yearDiff--;
                monthDiff=12+monthDiff;
            }
            else{
                System.out.println("invalid");
            }
        }
        System.out.println(dayDiff+" "+ monthDiff+" "+ yearDiff);
        for (int x = 0; x <= monthDiff - 1; x++) {
            //System.out.println(monthT+" "+months+" "+x);
            if ((monthT + x) % 2 == 1) {
                if (monthT + x == 7) {
                    dayAmt = dayAmt + 30;
                } else {
                    dayAmt = dayAmt + 31;
                }
            } else if ((monthT + x) == 2) {
                dayAmt = dayAmt + 28;
            } else if ((monthT + x) % 2 == 0) {
                dayAmt = dayAmt + 30;
            }
        }
        dayAmt=dayAmt+dayDiff;
        if(yearDiff>0){
            dayAmt=dayAmt+(yearDiff*365);
        }
        System.out.print(dayAmt);
        Main watch= new Main(dayAmt);
        Thread thread = new Thread(watch);
        thread.start();
    }
    }
    }

