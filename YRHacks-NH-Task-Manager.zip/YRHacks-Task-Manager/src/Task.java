import java.util.Date;
import java.text.SimpleDateFormat;

public class Task implements Comparable<Task>{
    private String name;
    private String date;
    private String desc;
    private int countdown;
    private int completion;
    
    public Task(String name, String date, String desc) {
        this.name = name;
        this.date = date;
        this.desc = desc;
    }
    
    public void setName(String n) {
        name = n;
    }
    
    public String getName () {
        return name;
    }
    
    public void setDate(String d) {
        date = d;
    }
    
    public String getDate () {
        return date;
    }
    @Override
    public String toString (){
        String output  = date+"\t"+name+"\t"+desc;
        return output;
    }

    @Override
    public int compareTo(Task t) {
        int task = this.date.substring(6).compareTo((t.date.substring(6)));
        if (task != -1){
            task = this.date.substring(3,5).compareTo((t.date.substring(3,5)));
            if (task != -1){
                task = this.date.substring(0,2).compareTo((t.date.substring(0,2)));
            }
        }
       return task;
    }
}
