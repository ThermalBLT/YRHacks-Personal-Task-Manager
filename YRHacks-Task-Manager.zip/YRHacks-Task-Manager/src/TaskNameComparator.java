
import java.util.Comparator;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aaron
 */
public class TaskNameComparator implements Comparator<Task>{

    @Override
    public int compare(Task t1, Task t2) {
        int task = t1.getName().compareTo(t2.getName());
        return task;
    }
    
}
